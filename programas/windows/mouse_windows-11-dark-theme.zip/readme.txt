﻿=== Windows 11 dark theme Cursor Set ===

By:  AKGAMER (http://www.rw-designer.com/user/98744) akkidhanasiri@gmail.com

Download: http://www.rw-designer.com/cursor-set/windows-11-dark-theme

Author's description:

New version of windows dark theme cursors,
if you do not have this new version then enjoy using the cursors of it!

Credit to - Windows 11 Cursors Concept v2 for making these cursors on devian art.
join my discord server - https://discord.gg/4sVKK3aq

My forum topic - http://www.rw-designer.com/forum/6085

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.