﻿=== Windows 11 Light Theme Cursor Set ===

By: GeorgiosNexus (http://www.rw-designer.com/user/101443) georgios1spanos@gmail.com 

Download: http://www.rw-designer.com/cursor-set/windows-11-light-theme

Author's description:

Hello everyone! New version of Windows Light Theme cursors. Gredits to Windows 11 Cursors Concept v2 by Jepri Creations rosea92 at DevianArt !
Gredits to https://www.deviantart.com/rosea92/art/Windows-11-Cursors-Concept-v2-886489356
I hope you enjoy it and like it as much or more this next gen modern cursor set! 

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.